import { Component, OnInit, ViewChild } from '@angular/core';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';


export interface PeriodicElement {
  price: number;
  productName: string;
  category: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {productName: 'Urban king 50W Wedge LED White Flood Light, Pack Of 1, (IP-65)', price: 130, category: 'Home & Kitchen'},
  {productName: `Men's Regular Fit T-Shirt (Pack of 3)`, price: 493, category: 'Fashion'},
  {productName: `Yashika womens Saree`, price: 279, category: 'Fashion'},
  {productName: `Anni Designer Women's Linen Cotton Printed Saree With Blouse Piece`, price: 379, category: 'Fashion'},
  {productName: 'New Apple MacBook Air with Apple M1 Chip (13-inch, 8GB RAM, 256GB SSD) - Gold (Latest Model)', price: 92900, category: 'Electronics'},
  {productName: 'OPPO F19 (Midnight Blue, 6GB RAM, 128GB Storage) with No Cost EMI/Additional Exchange Offers', price: 18990, category: 'Mobiles'},
  {productName: 'Lava Z2 (2GB RAM, 32GB Storage)- Aqua Blue', price: 7400, category: 'Mobiles'},
  {productName: 'Redmi 9A (Nature Green, 2GB Ram, 32GB Storage) | 2GHz Octa-core Helio G25 Processor', price: 6799, category: 'Mobiles'}
];

@Component({
  selector: 'app-sorting-table',
  templateUrl: './sorting-table.component.html',
  styleUrls: ['./sorting-table.component.scss']
})
export class SortingTableComponent implements OnInit {

  displayedColumns: string[] = ['productName', 'price', 'category'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  @ViewChild(MatSort) sort: MatSort;

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }

  constructor() { }

  ngOnInit(): void {
  }

}







